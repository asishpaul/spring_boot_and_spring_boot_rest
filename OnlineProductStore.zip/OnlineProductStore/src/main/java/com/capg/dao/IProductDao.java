package com.capg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.Model.ProductBean;

@Repository("productDao")
@Transactional
public interface IProductDao extends JpaRepository<ProductBean,Integer>{

	@Query( "from ProductBean where concat(Category,productName,Description) like %:input% ")
	public List<ProductBean> findProduct(@Param("input") String input);
		
	
	
}
